Objective:
-------------

To understand servlet life cycle.
To read http request parameters.

Existing resources:
--------------------------------

1.categories.html:-							This page will display product categories.
2.bookCatelogue.html:-						This page will display book catalogue.  
3.Class_Diagram.GIF:-					This image will describe java classes that needs to be created.   

Update following resources:
------------------------------------

1.DisplayCartDetailsServlet.java:-	This servlet should read products selected by web-client from bookCatelogue.html and 
														display them in tabular format as html response to the web client.
2.web.xml:-										This is the deployment descriptor for the web application.

Note:
-------

Please, do not make changes in EXISTING RESOURCES.



														