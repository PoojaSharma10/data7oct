package com.simulationdemo;

public abstract interface Pet {
	final static int MAX_ALLOWED=14;
	
	public abstract void beFriendly();
	void play();
}
